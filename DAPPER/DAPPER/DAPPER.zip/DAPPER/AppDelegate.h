//
//  AppDelegate.h
//  DAPPER
//
//  Created by xu jason on 14-3-22.
//  Copyright (c) 2014年 Vbenz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
